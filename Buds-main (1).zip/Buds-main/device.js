/* 기기 판별: 어떤 기기(아이폰/갤럭시/컴퓨터)이고, 폰인지 패드인지 컴퓨터인지 한 번만 정해서 모든 페이지가 같이 쓴다.
   - 폰      -> 휴대폰 앱
   - 패드    -> 컴퓨터 앱
   - 컴퓨터  -> 컴퓨터 앱
   - 아이폰(사파리): 화면 모양은 그대로 두고 사파리에서만 생기는 문제를 고친다
   - 갤럭시(안드로이드): 기본 그대로, 열고 처음 한 번 누르면 전체 화면
   확인용으로 주소 뒤에 ?device=phone / tablet / desktop 을 붙이면 그 기기인 것처럼 열린다. */
(function (w) {
  'use strict';

  /* ---- 1. 기기 알아보기 (판별만 하는 함수: 테스트하기 쉽게 값을 받아서 돌려준다) ---- */
  function detect(env) {
    var ua = env.ua || '', platform = env.platform || '', tp = env.touch || 0;
    var sw = env.sw || 0, sh = env.sh || 0, side = Math.min(sw, sh) || 0;
    var uaMobile = env.uaMobile; /* userAgentData.mobile, 없으면 undefined */
    var uaPlat = (env.uaPlatform || '').toLowerCase();

    var iphone = /iPhone|iPod/.test(ua);
    var ipad = /iPad/.test(ua) || (platform === 'MacIntel' && tp > 1); /* 아이패드는 맥인 척 한다 */
    var ios = iphone || ipad;
    var android = /Android/i.test(ua) || uaPlat === 'android';

    /* 안드로이드 크롬/삼성 인터넷의 '데스크톱 사이트' 모드는 리눅스 컴퓨터인 척 한다.
       터치가 되고 실제 화면(창 크기가 아니라 기기 화면)이 태블릿만 하면 컴퓨터가 아니라 태블릿이다 */
    var fakeDesktopAndroid = !android && !ios && /X11; Linux|Linux x86_64|Linux aarch64/.test(ua) &&
      !/CrOS/.test(ua) && tp > 0 && side > 0 && side <= 1000 && Math.max(sw, sh) <= 1700;
    if (fakeDesktopAndroid) android = true;

    var os = ios ? 'ios' : android ? 'android' : 'other';
    var cls;
    if (ios) cls = iphone ? 'phone' : 'tablet';
    else if (android) {
      if (uaMobile === true) cls = 'phone';
      else if (/Mobile/i.test(ua)) cls = 'phone';
      else if (side && side < 600) cls = 'phone';
      else cls = 'tablet'; /* 'Mobile'이 없는 안드로이드, 또는 데스크톱 모드 = 패드 */
    } else cls = 'desktop';
    return { os: os, cls: cls, iphone: iphone, ipad: ipad };
  }

  var nav = w.navigator || {}, scr = w.screen || {}, q;
  try { q = new URLSearchParams(w.location.search); } catch (e) { q = new URLSearchParams(''); }
  var uad = nav.userAgentData;
  var D = detect({
    ua: nav.userAgent, platform: nav.platform, touch: nav.maxTouchPoints,
    sw: scr.width, sh: scr.height,
    uaMobile: uad && typeof uad.mobile === 'boolean' ? uad.mobile : undefined,
    uaPlatform: uad && uad.platform
  });
  var forced = q.get('device');
  if (forced === 'phone' || forced === 'tablet' || forced === 'desktop') {
    D.cls = forced;
    if (forced === 'desktop') { D.os = 'other'; D.iphone = D.ipad = false; }
  }
  D.detect = detect;
  w.__DEV = D;
  /* 어떤 화면으로 보여줄지:
       phone -> native:true  (휴대폰 앱 그대로, 화면 가득)
       tablet -> 컴퓨터 앱   (버즈 앱만은 아이폰 목업 안에서 열린다: ?ui=phone&open=buds)
       desktop -> 컴퓨터 앱 (기본). 창이 넓은 컴퓨터에서만 오른쪽 아래 '휴대폰/컴퓨터' 전환 알약이 나온다
     창이 900px보다 좁은 컴퓨터는 예전처럼 휴대폰 화면 그대로 보여준다 */
  D.mode = function () {
    if (D.cls === 'phone') return { ui: 'phone', toggle: false, native: true };
    var ui = q.get('ui');
    if (D.cls === 'tablet') return { ui: ui === 'phone' && q.has('open') ? 'phone' : 'desk', toggle: false, native: false };
    var wide = false;
    try { wide = w.matchMedia('(min-width: 900px) and (pointer: fine)').matches; } catch (e) {}
    if (!wide) return { ui: 'phone', toggle: false, native: true };
    if (!ui) { try { ui = w.localStorage.getItem('apps.ui'); } catch (e) {} }
    return { ui: ui === 'phone' ? 'phone' : 'desk', toggle: true, native: false };
  };

  var R = w.document && w.document.documentElement;
  if (!R) return;
  R.classList.add('dev-' + D.cls, 'os-' + D.os);
  if (D.os === 'ios') R.classList.add('ios');
  if (D.os === 'android') R.classList.add('android');

  /* 화면 안(iframe, 목업 안의 앱)은 바깥 페이지가 이미 처리했으니 아래 손질은 맨 위 페이지에서만 한다 */
  var inFrame = w !== w.top;

  /* ---- 2. 아이폰 사파리 최적화: 보이는 것(UI, 애니메이션)은 하나도 바꾸지 않는다 ---- */
  if (D.os === 'ios' && !inFrame) {
    var css =
      /* 가로로 돌릴 때 글자가 제멋대로 커지는 것 */
      'html{-webkit-text-size-adjust:100%;text-size-adjust:100%}' +
      /* 두 번 눌렀을 때 화면이 확대되는 것과 누를 때 잠깐 기다리는 것.
         우선순위가 0 이라서 앱이 직접 정해 둔 touch-action(스와이프용 pan-y, none 등)은 그대로 이긴다 */
      '*{touch-action:manipulation}' +
      /* 위아래 끝에서 화면 전체가 고무줄처럼 늘어나며 앱이 밀리는 것 (사파리 16+). 가로는 앱의 스와이프를 위해 건드리지 않는다 */
      'html,body{overscroll-behavior-y:none}' +
      /* 버튼이나 그림을 길게 눌렀을 때 뜨는 복사/저장 메뉴 */
      'button,a,img,svg,canvas,[role=button],[role=switch]{-webkit-touch-callout:none}' +
      'img,canvas{-webkit-user-select:none;user-select:none}' +
      /* 누른 곳이 파랗게 반짝이는 것 */
      '*{-webkit-tap-highlight-color:transparent}';
    var st = w.document.createElement('style');
    st.setAttribute('data-ios-safari', '');
    st.textContent = css;
    (w.document.head || R).appendChild(st);

    /* 가격·날짜 같은 숫자가 파란 전화번호/링크로 바뀌는 것 */
    var fd = w.document.createElement('meta');
    fd.name = 'format-detection';
    fd.content = 'telephone=no,date=no,address=no,email=no';
    (w.document.head || R).appendChild(fd);

    /* 입력칸을 누르면 사파리가 화면을 확대해 버리는 것: 글자 크기를 바꾸지 않고 막는다 */
    var vp = w.document.querySelector('meta[name=viewport]');
    if (vp && !/maximum-scale/.test(vp.content)) vp.content += ',maximum-scale=1';

    /* 손가락 두 개로 벌려서 확대되는 것 (사파리는 viewport 설정을 무시한다) */
    ['gesturestart', 'gesturechange', 'gestureend'].forEach(function (n) {
      w.document.addEventListener(n, function (e) { e.preventDefault(); }, { passive: false });
    });
  }

  /* ---- 3. 갤럭시(안드로이드): 기본 그대로 + 열고 처음 한 번 누르면 전체 화면 ---- */
  if (D.os === 'android' && !inFrame) {
    /* 홈 화면에 추가해서 열면 주소창 없이 처음부터 전체 화면이 되도록 manifest 를 안드로이드에만 단다 */
    var mf = w.document.createElement('link');
    mf.rel = 'manifest';
    mf.href = 'manifest.webmanifest';
    (w.document.head || R).appendChild(mf);
    try { if (nav.serviceWorker) nav.serviceWorker.register('sw.js').catch(function () {}); } catch (e) {}

    var d = w.document;
    var isFull = function () { return !!(d.fullscreenElement || d.webkitFullscreenElement); };
    var installed = function () {
      try { return w.matchMedia('(display-mode: fullscreen)').matches || w.matchMedia('(display-mode: standalone)').matches; } catch (e) { return false; }
    };
    var armed = true;
    var goFull = function () {
      if (!armed || isFull() || installed()) return;
      var el = d.documentElement, req = el.requestFullscreen || el.webkitRequestFullscreen;
      if (!req || !(d.fullscreenEnabled || d.webkitFullscreenEnabled)) { armed = false; return; }
      try {
        var p = req.call(el, { navigationUI: 'hide' });
        if (p && p.then) p.then(function () { armed = false; }, function () { /* 이번엔 안 됨: 다음 누름에 다시 */ });
        else armed = false;
      } catch (e) { /* 다음 누름에 다시 */ }
    };
    /* 브라우저는 '사용자가 누른 순간'에만 전체 화면을 허락한다. 누르는 동작은 그대로 앱에도 전달된다 */
    ['pointerup', 'touchend', 'click'].forEach(function (n) {
      d.addEventListener(n, goFull, { capture: true, passive: true });
    });
    /* 사용자가 직접 전체 화면을 끝냈으면 다시 강제로 켜지 않는다. 다른 페이지로 넘어오면 그때 첫 누름에 다시 켠다 */
    ['fullscreenchange', 'webkitfullscreenchange'].forEach(function (n) {
      d.addEventListener(n, function () { if (!isFull()) armed = false; });
    });
  }
})(window);
