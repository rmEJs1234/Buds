/* 홈 화면에 설치할 수 있게 해 주는 최소한의 서비스 워커. 아무것도 저장(캐시)하지 않고 요청은 그대로 통과시킨다 */
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
